setTimeout(async function(){
    const containerHome = document.getElementById('containerHome');
    let homeMovies = await getApi();
    console.log(homeMovies)
    let cards = ``;
    homeMovies.results.forEach(e => {
        cards += `<div class="w-full h-full bg-cover bg-center mb-4 z-1" style="background-image: url('https://image.tmdb.org/t/p/w500${e.backdrop_path}')"></div>`;
    });
    containerHome.innerHTML = cards;
},0)



function getApi(){
    return fetch(`https://api.themoviedb.org/3/movie/popular?api_key=8482e16292527bd819173faa9e3fb365`)
    .then(e => e.json())
    .then(e => (e.length===0)?'Movie Not Found' : e);
}

// | Kebutuhan                    | Endpoint URL                       |
// | ---------------------------- | ---------------------------------- |
// | 🔥 Movie populer             | `/movie/popular`                   |
// | 🎬 Movie terbaru             | `/movie/now_playing`               |
// | 🧭 Movie mendatang           | `/movie/upcoming`                  |
// | 📺 TV Series populer         | `/tv/popular`                      |
// | 🔎 Cari film/tv show         | `/search/movie?q=...`              |
// | 🎞️ Detail film              | `/movie/{movie_id}`                |
// | 👥 Cast & crew film          | `/movie/{movie_id}/credits`        |
// | 📽️ Trailer & video film     | `/movie/{movie_id}/videos`         |
// | 🎭 Daftar genre              | `/genre/movie/list`                |
// | 🌍 Filter berdasarkan negara | Gunakan parameter `region=ID`      |
// | 🔢 Rating / Vote             | Dalam detail film (`vote_average`) |
// | 📚 Koleksi/franchise         | `/collection/{collection_id}`      |
