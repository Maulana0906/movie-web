const dataGenre = [
  { "id": 28, "name": "Action" },
  { "id": 12, "name": "Adventure" },
  { "id": 16, "name": "Animation" },
  { "id": 35, "name": "Comedy" },
  { "id": 80, "name": "Crime" },
  { "id": 99, "name": "Documentary" },
  { "id": 18, "name": "Drama" },
  { "id": 10751, "name": "Family" },
  { "id": 14, "name": "Fantasy" },
  { "id": 36, "name": "History" },
  { "id": 27, "name": "Horror" },
  { "id": 10402, "name": "Music" },
  { "id": 9648, "name": "Mystery" },
  { "id": 10749, "name": "Romance" },
  { "id": 878, "name": "Science Fiction" },
  { "id": 10770, "name": "TV Movie" },
  { "id": 53, "name": "Thriller" },
  { "id": 10752, "name": "War" },
  { "id": 37, "name": "Western" }
]
let second;
setTimeout(async function(){
    const containerHome = document.getElementById('backgroundContent');
    const thumbButton = document.getElementById('thumbButton');
    const textContainerHome = document.getElementById('textContainerHome');
    let homeMovies = await getApi();
    second = homeMovies;
    let active = 0;
    homeMovies.results.forEach((e,i) => {
        const bgWrapper = document.createElement('div');
        let hiddenClass = (i==active)?'background-on':'background-off';
        bgWrapper.className = `w-full h-full bg-cover bg-center mb-4 ${hiddenClass} absolute z-[${i}] `;
        bgWrapper.style.backgroundImage = `url('https://image.tmdb.org/t/p/w500${e.backdrop_path}')`;
        containerHome.appendChild(bgWrapper);

        const thumb = document.createElement('div');
        let filter = (active!=i) ? 'off' : 'on';
        let classActive = (i==active)?'thumb-on' : 'thumb-off';
        thumb.className = `inline-block mx-1 w-24 h-[140px] ${classActive} rounded-lg overflow-hidden cursor-pointer relative duration-200 ease-in-out`;
        thumb.innerHTML = `<div class="h-full w-full absolute ${filter} bg-gray-900 duration-200 ease-in-out"> </div> 
        <img class='w-full h-full object-cover' src="https://image.tmdb.org/t/p/w500${e.poster_path}" /> `;
        thumbButton.appendChild(thumb);
        if(active==i){
            textContainerHome.innerHTML= textHome(e);
        }
    });
    const thumbnails = thumbButton.children;
    Array.from(thumbnails).forEach((e,i)=> {
        e.addEventListener('click', (el)=> {
            uiTumbButton(i,thumbnails,containerHome);
            if(i>1){
                let count = (active===0) ? 1 : i-active;
                thumbButton.scrollLeft += (104 *count);
            }else{
                thumbButton.scrollLeft-= 104;
            }
            active = i;
            let temp = textHome(second.results[i]);
            // console.log(second.results[i])
            textContainerHome.innerHTML = temp;
        })
    })

},0)
function uiTumbButton(index,thumbnails,containerHome){
    const bgWrappers = containerHome.children;
    Array.from(thumbnails).forEach((e,i)=> {
        const thumbnailsInner = e.children[0];
        if(i==index){
            thumbnailsInner.classList.replace('off', 'on');
            e.classList.replace('thumb-off','thumb-on');
            bgWrappers[i].classList.replace('background-off', 'background-on')            
        }else{
            e.classList.replace('thumb-on','thumb-off')
            thumbnailsInner.classList.replace('on', 'off');
            bgWrappers[i].classList.replace('background-on', 'background-off');
        }
    })

}

function textHome(data){
    let findGenre = function(x) {
        for(let a of dataGenre){
             if(a.id == x){return a.name}
        }
    }
    let genre = data.genre_ids.map((e,i) => 
        (data.genre_ids[i+1] !=undefined)?`<h3 class="font-medium">${findGenre(e)}</h3> <div class=" h-4 bg-white" style="width: 2px;"></div>`
        :`<h3 class="font-medium">${findGenre(e)}</h3>`
    ).join('');
    return `
    <h1 class="text-5xl font-semibold">${data.original_title}</h1>
    <div class="my-1 flex items-center gap-1">
        ${genre}
    </div>
    <p class="leading-4 text-sm">${data.overview}</p>
    <div class="flex items-end gap-1 mb-2">
      <img src="img/star-f.png" alt="" class="w-4 h-4 ">
      <img src="img/star-f.png" alt="" class="w-4 h-4">
      <img src="img/star-f.png" alt="" class="w-4 h-4">
      <img src="img/star-f.png" alt="" class="w-4 h-4">
      <img src="img/star-f.png" alt="" class="w-4 h-4">
      <span class="leading-none">${data.vote_average}</span>
      <img src="img/fire.png" class="h-5 w-5 ml-3" style="margin-bottom: -1px;" alt="">
      <span class="leading-none">${data.popularity}</span>
    </div>
    <button class="moreInfo relative inline-flex items-center justify-center p-0.5 mb-2 me-2 overflow-hidden text-sm font-medium text-gray-900 rounded-2xl group bg-gradient-to-br from-cyan-500 to-blue-500 group-hover:from-cyan-500 group-hover:to-blue-500 hover:text-white dark:text-white focus:ring-4 focus:outline-none focus:ring-cyan-200 dark:focus:ring-cyan-800">
      <span class="moreInfo relative cursor-pointer px-5 py-2 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-2xl group-hover:bg-transparent group-hover:dark:bg-transparent">
        More info <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
      </span>
    </button>`
}

function getApi(){
    return fetch(`https://api.themoviedb.org/3/movie/popular?api_key=8482e16292527bd819173faa9e3fb365`)
    .then(e => e.json())
    .then(e => (e.length===0)?'Movie Not Found' : e);
}

// | Kebutuhan                    | Endpoint URL                       |
// | ---------------------------- | ---------------------------------- |
// | 🔥 Movie populer             | `/movie/popular`                   |
// | 🎬 Movie terbaru             | `/movie/now_playing`               |
// | 🧭 Movie mendatang           | `/movie/upcoming`                  |
// | 📺 TV Series populer         | `/tv/popular`                      |
// | 🔎 Cari film/tv show         | `/search/movie?q=...`              |
// | 🎞️ Detail film              | `/movie/{movie_id}`                |
// | 👥 Cast & crew film          | `/movie/{movie_id}/credits`        |
// | 📽️ Trailer & video film     | `/movie/{movie_id}/videos`         |
// | 🎭 Daftar genre              | `/genre/movie/list`                |
// | 🌍 Filter berdasarkan negara | Gunakan parameter `region=ID`      |
// | 🔢 Rating / Vote             | Dalam detail film (`vote_average`) |
// | 📚 Koleksi/franchise         | `/collection/{collection_id}`      |
